﻿namespace Circle
{
    public static class Program
    {
        static void Main()
        {
            Double pi = 3.14;
            Console.WriteLine("enter the radius of circle :");
            Double r = Convert.ToDouble(Console.ReadLine());
            
            AreaAndCircumference(r);
        }
        public static void AreaAndCircumference(double r)
        {
            double pi = 3.14;
            double Area = pi * r * r;
            Console.WriteLine("the area is {0} : " , Area);
            double Circumference = 2 * pi * r;
            Console.WriteLine("the circumference is {0} : ", Circumference);
        }
    }
}