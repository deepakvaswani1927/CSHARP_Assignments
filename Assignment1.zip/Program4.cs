﻿namespace Swaping
{
    public static class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter the first number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            num1 = num1 + num2;
            num2 = num1 - num2;
            num1 = num1 - num2;
            Console.WriteLine("first number is : {0}", num1);
            Console.WriteLine("second number is : {0}", num2);
        }
    }
}