﻿using System;

namespace Calculator
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter 1st number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the operation you want to performed");
            Console.WriteLine("Press A for Addition");
            Console.WriteLine("Press S for Subtraction");
            Console.WriteLine("Press M for Multiplication");
            Console.WriteLine("Press D for Division \n");
            int operation = Convert.ToChar(Console.ReadLine());

            int result = 0;
            switch (operation)
            {
                case 'A':
                    {
                        result = Addition(num1, num2);
                        break;
                    }
                case 'S':
                    {
                        result = Subtraction(num1, num2);
                        break;
                    }
                case 'M':
                    {
                        result = Multiplication(num1, num2);
                        break;
                    }
                case 'D':
                    {
                        result = Division(num1, num2);
                        break;
                    }
                default:
                    Console.WriteLine("Wrong action!! try again");
                    break;
            }
            Console.WriteLine("The result is {0}", result);
            Console.ReadKey();
        }
        public static int Addition(int num1, int num2)
        {
            int result = num1 + num2;
            return result;
        }
        public static int Subtraction(int num1, int num2)
        {
            int result = num1 - num2;
            return result;
        }
        public static int Multiplication(int num1, int num2)
        {
            int result = num1 * num2;
            return result;
        }
        public static int Division(int num1, int num2)
        {
            int result = num1 / num2;
            return result;
        }
    }
}